Tệp nén thử nghiệm.
